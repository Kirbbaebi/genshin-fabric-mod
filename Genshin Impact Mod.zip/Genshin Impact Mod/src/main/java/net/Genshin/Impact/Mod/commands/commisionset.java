package net.Genshin.Impact.Mod.commands;

public class commisionset {

}
