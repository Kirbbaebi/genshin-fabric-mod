package net.Genshin.Impact.Mod.ext;

public interface PlayerEntityExt {
    static void GotBook() {};
    void addFourPity(int amount);
    void addFivePity(int amount);
}
